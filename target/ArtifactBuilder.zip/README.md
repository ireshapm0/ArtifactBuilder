ArtifactBuilder
===============

Jaggery App to create a WSO2 Greg RXT artifact

This App uses Bootsnipp Form Builder web app to create drag drop bootstrap form elements.
(https://github.com/minikomi/Bootstrap-Form-Builder)
